from fastapi import FastAPI
from pydantic import BaseModel, Field
from src.agents import ask_agent

app = FastAPI(
    title="BFSI Multi-Agent System",
    version="1.0",
    description="Ministry of Finance Annual Report Analysis using LangGraph Multi-Agent RAG System"
)


class QueryRequest(BaseModel):

    question: str = Field(
        ...,
        description="User Question"
    )


@app.get("/")
def home():

    return {
        "message": "BFSI Multi-Agent System is running"
    }


@app.get("/health")
def health():

    return {
        "status": "healthy"
    }


@app.post("/ask")
def ask(request: QueryRequest):

    result = ask_agent(
        request.question
    )

    return {
        "answer": result["answer"]
    }