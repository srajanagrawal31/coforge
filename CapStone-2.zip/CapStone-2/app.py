import streamlit as st
import requests

API_URL = "http://127.0.0.1:8000/ask"

st.set_page_config(
    page_title="BFSI Multi-Agent System",
    layout="wide"
)

st.title("🏦 BFSI Multi-Agent Intelligence System")

st.markdown(
    """
    Ask questions about Ministry of Finance and
    Department of Financial Services Annual Reports.
    """
)

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

user_query = st.text_input(
    "Enter your query"
)

if st.button("Ask Question"):

    if user_query.strip() == "":
        st.warning("Please enter a question.")

    else:

        with st.spinner(
            "Analyzing reports..."
        ):

            try:

                response = requests.post(
                    API_URL,
                    json={
                        "question": user_query
                    }
                )

                response.raise_for_status()

                result = response.json()

                answer = result.get(
                    "answer",
                    "No answer generated."
                )

                evaluation = result.get(
                    "evaluation",
                    "No evaluation available."
                )

                sources = result.get(
                    "sources",
                    []
                )

                st.session_state.chat_history.append(
                    {
                        "question": user_query,
                        "answer": answer,
                        "evaluation": evaluation,
                        "sources": sources
                    }
                )

            except Exception as e:

                st.error(
                    f"Error: {str(e)}"
                )

st.divider()

for chat in reversed(
    st.session_state.chat_history
):

    st.markdown("### 👤 User")

    st.write(
        chat["question"]
    )

    st.markdown(
        "### 🤖 BFSI Intelligence Assistant"
    )

    st.write(
        chat["answer"]
    )

    with st.expander(
        "Evaluation Report"
    ):

        st.write(
            chat["evaluation"]
        )

    with st.expander(
        "Sources"
    ):

        if len(chat["sources"]) > 0:

            for source in chat["sources"]:

                st.write(
                    f"📄 {source.get('source','Unknown')} | "
                    f"Page {source.get('page','?')}"
                )

        else:

            st.write(
                "No sources available."
            )

    st.divider()