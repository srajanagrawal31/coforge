agentic-rag/
│
├── src/
│   ├── rag_pipeline.py
│   └── ingest.py
│
├── main.py
├── app.py (frontend)
│
├── faiss_index/
├── requirements.txt
├── README.md
└── .env (Storing all APIs)  