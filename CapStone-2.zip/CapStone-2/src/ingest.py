import os
from dotenv import load_dotenv
from langchain_community.document_loaders import (DirectoryLoader, PyPDFLoader)
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_openai import AzureOpenAIEmbeddings

load_dotenv()

api_key = os.getenv("AZURE_OPENAI_API_KEY")
endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
deployment = os.getenv("EMBEDDING_DEPLOYMENT_NAME")

loader = DirectoryLoader("./data",glob="**/*.pdf",loader_cls=PyPDFLoader)

documents = loader.load()

print(f"Loaded {len(documents)} pages")

recursive_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=100,
    separators=[
        "\n\n",
        "\n",
        ".",
        " "
    ]
)

chunks = recursive_splitter.split_documents(documents)

print(f"Total Chunks Created: {len(chunks)}")

azure_openai_embeddings = AzureOpenAIEmbeddings(
    azure_endpoint=endpoint,
    api_key=api_key,
    azure_deployment=deployment
)

faiss_store = FAISS.from_documents(
    documents=chunks,
    embedding=azure_openai_embeddings
)

faiss_store.save_local("faiss_index")

print("FAISS Index Created Successfully")
print("Saved in ./faiss_index")