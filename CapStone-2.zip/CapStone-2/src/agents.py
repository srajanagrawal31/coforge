from typing import TypedDict
from langgraph.graph import (StateGraph, START, END)
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
import os
from src.rag import (load_pipeline,ask_question)

load_dotenv()

llm = ChatOpenAI(
    api_key=os.getenv("AZURE_GPT_API_KEY"),
    base_url=os.getenv("AZURE_GPT_ENDPOINT"),
    model=os.getenv("AZURE_GPT_DEPLOYMENT_NAME"),
    temperature=1
)

rag_chain = load_pipeline()

class BFSIState(TypedDict):
    user_query: str
    planner_output: str
    rag_output: str
    retrieved_docs: list
    sources: list
    analyst_output: str
    report_output: str
    evaluation_output: str
    final_answer: str

PLANNER_PROMPT = """
You are a BFSI Query Planning Agent.

Analyze the user query.

Identify:

1. Query Type
   - summary
   - comparison
   - policy
   - trend
   - factual

2. Topic

3. What information is required
   from the annual reports.

Return a structured plan.
"""

def planner_agent(state: BFSIState):

    query = state["user_query"]
    response = llm.invoke(
        f"""
        {PLANNER_PROMPT}

        User Query:
        {query}
        """
    )

    return {
        **state,
        "planner_output": response.content
    }

def agentic_rag_agent(state: BFSIState):

    query = f"""
    User Query:
    {state['user_query']}

    Retrieval Plan:
    {state['planner_output']}
    """
    rag_result = ask_question(
        rag_chain,
        query
    )

    return {
    **state,
    "rag_output": "\n\n".join(
        rag_result["retrieved_docs"]
    ),
    "retrieved_docs": rag_result["retrieved_docs"],
    "sources": rag_result["sources"]
}

ANALYST_PROMPT = """
You are a BFSI Analyst.
Analyze the retrieved information.
Generate:
1. Key Findings
2. Policy Insights
3. Regulatory Observations
4. Trends Across Years
5. Strategic Implications

Only use the supplied information.
"""

def analyst_agent(state: BFSIState):

    response = llm.invoke(
        f"""
        {ANALYST_PROMPT}

        Planner Output:
        {state['planner_output']}

        Retrieved Information:
        {state['rag_output']}
        """
    )

    return {
        **state,
        "analyst_output": response.content
    }

REPORTER_PROMPT = """
You are a BFSI Executive Reporter.
Create a professional report.
Format:
Executive Summary

Key Findings

Trend Analysis

Strategic Implications

Conclusion

Use clear and concise language.
"""

def executive_reporter_agent(state: BFSIState):

    response = llm.invoke(
        f"""
        {REPORTER_PROMPT}

        Analysis:
        {state['analyst_output']}
        """
    )

    return {
        **state,
        "report_output": response.content
    }

EVALUATOR_PROMPT = """
You are a BFSI Quality Evaluator.

Evaluate the report.

Check:

1. Does the report answer the user query?
2. Is it grounded in retrieved information?
3. Is information complete?
4. Are findings logical?

Return:
Status: APPROVED or NEEDS_IMPROVEMENT
Reason:

Final Evaluation:
"""

def evaluator_agent(state: BFSIState):

    response = llm.invoke(
        f"""
        {EVALUATOR_PROMPT}

        User Query:
        {state['user_query']}

        Retrieved Information:
        {state['rag_output']}

        Report:
        {state['report_output']}
        """
    )

    return {
        **state,
        "evaluation_output": response.content,
        "final_answer": state["report_output"]
    }

graph = StateGraph(BFSIState)

graph.add_node(
    "planner_agent",
    planner_agent
)

graph.add_node(
    "agentic_rag_agent",
    agentic_rag_agent
)

graph.add_node(
    "analyst_agent",
    analyst_agent
)

graph.add_node(
    "executive_reporter_agent",
    executive_reporter_agent
)

graph.add_node(
    "evaluator_agent",
    evaluator_agent
)

graph.add_edge(
    START,
    "planner_agent"
)

graph.add_edge(
    "planner_agent",
    "agentic_rag_agent"
)

graph.add_edge(
    "agentic_rag_agent",
    "analyst_agent"
)

graph.add_edge(
    "analyst_agent",
    "executive_reporter_agent"
)

graph.add_edge(
    "executive_reporter_agent",
    "evaluator_agent"
)

graph.add_edge(
    "evaluator_agent",
    END
)

bfsi_graph = graph.compile()

bfsi_graph = graph.compile()

print("\n===== LANGGRAPH WORKFLOW =====\n")
print(bfsi_graph.get_graph().draw_ascii())

def ask_agent(query):

    result = bfsi_graph.invoke(
        {
            "user_query": query
        }
    )

    return {
        "answer": result["final_answer"]
    }