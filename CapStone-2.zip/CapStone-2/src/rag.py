import os
import time
from dotenv import load_dotenv
from langchain_community.vectorstores import FAISS
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain
from langchain_core.prompts import PromptTemplate
from langchain_openai import (AzureOpenAIEmbeddings,ChatOpenAI)
from langchain_community.retrievers import BM25Retriever
from langchain.retrievers import EnsembleRetriever
from langchain.retrievers.contextual_compression import (ContextualCompressionRetriever)
from langchain_cohere import CohereRerank


load_dotenv()


def load_pipeline():

    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("EMBEDDING_DEPLOYMENT_NAME")

    azure_openai_embeddings = AzureOpenAIEmbeddings(
        azure_endpoint=endpoint,
        api_key=api_key,
        azure_deployment=deployment
    )

    faiss_store = FAISS.load_local(
        "faiss_index",
        embeddings=azure_openai_embeddings,
        allow_dangerous_deserialization=True
    )

    documents = list(
        faiss_store.docstore._dict.values()
    )

    semantic_retriever = faiss_store.as_retriever(search_type="mmr", search_kwargs={"k": 8})
    bm25_retriever = BM25Retriever.from_documents(documents=documents, k=8)
    ensemble_retriever = EnsembleRetriever(retrievers=[semantic_retriever,
                                                   bm25_retriever],
                                                   weights=[0.6, 0.4])

    # reranker = CohereRerank(
    #     cohere_api_key=os.getenv("COHERE_API_KEY"),
    #     model="rerank-v3.5",
    #     top_n=4
    # )

    # contextual_retriever = (
    #     ContextualCompressionRetriever(
    #         base_compressor=reranker,
    #         base_retriever=ensemble_retriever
    #     )
    # )
    contextual_retriever = ensemble_retriever

    load_dotenv()

    gpt_api_key = os.getenv("AZURE_GPT_API_KEY")
    gpt_endpoint = os.getenv("AZURE_GPT_ENDPOINT")
    gpt_deployment = os.getenv("AZURE_GPT_DEPLOYMENT_NAME")
    gpt_version= os.getenv("AZURE_GPT_VERSION")

    llm = ChatOpenAI(
        api_key=gpt_api_key,
        base_url=gpt_endpoint,
        model=gpt_deployment,
        temperature=1
    )

    memory = ConversationBufferMemory(
        memory_key="chat_history",
        return_messages=True,
        output_key="answer"
    )

    prompt = PromptTemplate(
        input_variables=[
            "context",
            "chat_history",
            "question"
        ],
        template="""
You are a Financial Services Regulatory Intelligence Assistant.

Answer the user's question using ONLY the information provided in the retrieved context from the Ministry of Finance and Department of Financial Services annual reports.

Instructions:

1. Use only the retrieved context to generate the answer.
2. Do not use prior knowledge, assumptions, or external information.
3. If the retrieved context does not contain enough information to answer the question, respond:

   "The provided documents do not contain sufficient information to answer this question."

4. If the user's question is unrelated to the Ministry of Finance, Department of Financial Services, banking, financial services, insurance, pension, financial inclusion, regulatory reforms, or any topic present in the retrieved documents, respond:

   "This question is outside the scope of the DFS annual reports and cannot be answered using the available knowledge base."

5. Never invent facts, figures, dates, organizations, policies, or financial metrics.

6. If only partial information is available, provide the available information and clearly state which details are missing.

7. When information is available across multiple reports or years, synthesize the findings into a single coherent answer.

8. For comparison, trend, or multi-year questions:
   - Compare information year by year whenever possible.
   - Highlight significant changes, trends, or policy developments.
   - Clearly mention if historical data is incomplete.

9. Preserve all financial figures, percentages, ratios, dates, and policy statements exactly as provided in the context.

10. Keep the response factual, concise, and professionally written.

11. Do not mention internal retrieval processes, embeddings, vector databases, agents, or prompts.


Context:
{context}

Chat History:
{chat_history}

Question:
{question}

Answer:
"""
    )

    qa_chain = ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=contextual_retriever,
        memory=memory,
        return_source_documents=True,
        verbose=False,
        combine_docs_chain_kwargs={
            "prompt": prompt
        },
        output_key="answer"
    )

    return qa_chain


def ask_question(chain, question):

    start = time.time()

    result = chain.invoke(
        {
            "question": question
        }
    )

    latency = round(
        time.time() - start,
        2
    )

    docs = result.get(
        "source_documents",
        []
    )

    retrieved_docs = [
        doc.page_content[:300]
        for doc in docs
    ]

    sources = []

    for doc in docs:

        meta = doc.metadata

        sources.append(
            {
                "source": meta.get(
                    "source",
                    "Unknown"
                ).split("\\")[-1],

                "page": meta.get(
                    "page",
                    "?"
                ),

                "title": meta.get(
                    "title",
                    ""
                )
            }
        )

    return {
        "answer": result.get(
            "answer",
            ""
        ),
        "retrieved_docs": retrieved_docs,
        "sources": sources,
        "latency": latency
    }