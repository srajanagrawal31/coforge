#Compare financial inclusion initiatives across the last 6 years.






from rag import load_pipeline, ask_question

chain = load_pipeline()

result = ask_question(
    chain,
    "What are the financial improvements introduced by government in last 2 years?"
)

print(result["answer"])
print(result["sources"])