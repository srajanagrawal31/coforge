from agents import ask_agent

result = ask_agent(
    "Compare financial inclusion initiatives across the last 6 years."
)

print(result)